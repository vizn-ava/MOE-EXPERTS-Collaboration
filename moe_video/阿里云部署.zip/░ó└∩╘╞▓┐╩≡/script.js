
console.log('axios是否加载成功:', typeof axios);

document.addEventListener('DOMContentLoaded', function () {
    // 移除input-text的input事件监听
    const inputText = document.getElementById('input-text');
    if (inputText) {
        // 移除原有的input事件监听
        // inputText.removeEventListener('input', processInput);
    } else {
        console.error('未找到id为input-text的元素');
    }

    const addButtons = document.querySelectorAll('.add-button');
    const svg = document.getElementById('branch-svg');
    let activeButtons = new Map(); // 用于存储每个按钮的分支状态


    // 绑定确认按钮的点击事件
    const confirmButton = document.getElementById('confirm-button');
    if (confirmButton) {
        confirmButton.addEventListener('click', processInput);
    } else {
        console.error('未找到id为confirm-button的元素');
    }

    const moeNetwork = document.getElementById('moe-network');
    const rows = 64; // 每列64个圆圈
    const cols = 27; // 共27列

    // 清空现有的内容
    moeNetwork.innerHTML = '';

    // 动态生成64x27的圆圈
    for (let i = 0; i < rows; i++) {
        for (let j = 0; j < cols; j++) {
            const circle = document.createElement('div');
            circle.classList.add('circle');
            moeNetwork.appendChild(circle);
        }
    }

    const tokenTableBody = document.querySelector('.token-table tbody');
    tokenTableBody.innerHTML = ''; // 清空token列表

    // 主题切换功能
    const themeToggle = document.getElementById('theme-toggle');
    if (themeToggle) {
        themeToggle.addEventListener('click', function() {
            document.body.classList.toggle('dark-theme');
            if (document.body.classList.contains('dark-theme')) {
                themeToggle.textContent = '☀️';
            } else {
                themeToggle.textContent = '🌙';
            }
        });
    }

    // 语言切换功能
    let currentLanguage = 'en'; // 默认英文
    
    const translations = {
        en: {
            title: 'MOE Expert Collaboration Mining Visualization',
            lang_toggle_title: 'Switch Language',
            lang_toggle_label: '中文',
            theme_toggle_title: 'Toggle Theme',
            guide_title: 'Usage Guide',
            guide_description: 'This page displays the activation and decomposition relationships of expert combinations in MOE models, providing interactive visualization.',
            guide_step1: 'Enter your text in the input box on the left and click "Confirm".',
            guide_step2: 'Click the "+" buttons in the Token List to query the corresponding Top 5 first-level expert combinations.',
            guide_step3: 'Click the "+" buttons in the first-level expert combinations to view Top 5 second-level expert combinations and visualization branches.',
            input_title: 'Input Text',
            confirm: 'Confirm',
            input_placeholder: 'Enter your text here...',
            token_list: 'Token List',
            first_experts_title: 'First-Level Expert Combinations',
            first_expert_index: 'Expert ID',
            first_expert_name: 'Expert Name (Function)',
            decompose_header: 'Decompose',
            second_experts_title: 'Second-Level Expert Combinations',
            second_expert_index: 'Expert ID',
            second_expert_name: 'Expert Name (Function)',
            network_title: 'Expert Group Mapping on MOE Network',
            footer: '© 2025 MOE Visualization Platform'
        },
        zh: {
            title: 'MOE专家协作挖掘可视化展示',
            lang_toggle_title: '切换语言',
            lang_toggle_label: 'EN',
            theme_toggle_title: '切换主题',
            guide_title: '使用指南',
            guide_description: '本页面用于展示MOE模型中专家组合的激活与分解关系，并提供交互式可视化。',
            guide_step1: '在左侧输入框中输入文本，点击"确认"。',
            guide_step2: '在Token列表中点击"+"查询对应的Top 5一级专家组合。',
            guide_step3: '在一级专家组合中点击"+"查看Top 5二级专家组合与可视化分支。',
            input_title: '输入文本',
            confirm: '确认',
            input_placeholder: '在此输入句子...',
            token_list: 'Token列表',
            first_experts_title: '一级专家组合',
            first_expert_index: '专家ID',
            first_expert_name: '专家名称（功能）',
            decompose_header: '分解',
            second_experts_title: '二级专家组合',
            second_expert_index: '专家ID',
            second_expert_name: '专家名称（功能）',
            network_title: '专家组在MOE网络上的映射',
            footer: '© 2025 MOE可视化平台'
        }
    };
    
    function updateLanguage() {
        const elements = document.querySelectorAll('[data-i18n]');
        elements.forEach(element => {
            const key = element.getAttribute('data-i18n');
            if (translations[currentLanguage][key]) {
                element.textContent = translations[currentLanguage][key];
            }
        });
        
        // 更新placeholder
        const inputText = document.getElementById('input-text');
        if (inputText) {
            inputText.placeholder = translations[currentLanguage].input_placeholder;
        }
        
        // 更新按钮文本
        const langToggle = document.getElementById('lang-toggle');
        if (langToggle) {
            langToggle.textContent = translations[currentLanguage].lang_toggle_label;
        }
    }
    
    // 语言切换按钮事件
    const langToggle = document.getElementById('lang-toggle');
    if (langToggle) {
        langToggle.addEventListener('click', function() {
            currentLanguage = currentLanguage === 'en' ? 'zh' : 'en';
            updateLanguage();
        });
    }
    
    // 初始化语言
    updateLanguage();

});

// 发送用户输入到后端并展示结果主要都是调试
async function processInput() {
    const inputText = document.getElementById('input-text').value;
    console.log('输入文本:', inputText); // 调试信息

    try {
        console.log('发送请求到后端'); // 调试信息
        const response = await axios.post('http://localhost:3000/api/process', { input: inputText }, {
            headers: {
                'Content-Type': 'application/json' // 设置请求头
            }
        });
        console.log('后端返回的数据:', response.data); // 调试信息

        const tokenVectors = response.data.tokenVectors;
        if (!tokenVectors || !Array.isArray(tokenVectors)) {
            console.error('tokenVectors 不是数组或未定义:', tokenVectors);
            return;
        }

        console.log('tokenVectors 数据:', tokenVectors); // 调试信息

        // 显示token列表
        displayTokenList(tokenVectors);
        console.log('displayTokenList 函数被调用'); // 调试信息

    } catch (error) {
        console.error('请求失败:', error);
    }
}

// 为按钮添加点击事件
function displayTokenList(tokenVectors) {
    const tokenTableBody = document.querySelector('.token-table tbody');
    if (!tokenTableBody) {
        console.error('未找到token表格的tbody元素');
        return;
    }

    // 清空现有的内容
    tokenTableBody.innerHTML = '';

    // 遍历tokenVectors，生成每一行的内容
    tokenVectors.forEach(tokenVector => {
        const row = document.createElement('tr');

        // 创建Token单元格
        const tokenCell = document.createElement('td');
        // 首字母大写
        const token = tokenVector.token;
        tokenCell.textContent = token.charAt(0).toUpperCase() + token.slice(1);
        row.appendChild(tokenCell);

        // 创建按钮单元格
        const buttonCell = document.createElement('td');
        const button = document.createElement('button');
        button.textContent = '+'; // 按钮文本
        button.classList.add('add-button'); // 添加按钮样式类

        // 保存激活向量到按钮的 data 属性
        button.dataset.activationVector = JSON.stringify(tokenVector.vector);

        button.addEventListener('click', async () => {
            console.log('按钮被点击，token:', tokenVector.token); // 调试信息
            console.log('激活向量:', JSON.parse(button.dataset.activationVector)); // 输出激活向量

            try {
                // 从按钮的 data 属性中获取激活向量
                const activationVector = JSON.parse(button.dataset.activationVector);

                // 发送请求查询Top 5专家
                const response = await axios.post('http://localhost:3000/api/top5-experts', {
                    tokenVector: activationVector
                });
                console.log('Top 5专家:', response.data); // 调试信息

                // 显示Top 5专家
                displayTop5Experts(response.data);

                // 根据激活向量点亮圆圈
                activateCirclesByVector(activationVector);

                // 高亮当前行和按钮
                const row = button.closest('tr');
                highlightRowAndButton(row, button, 'token');
            } catch (error) {
                console.error('查询Top 5专家失败:', error);
            }
        });
        buttonCell.appendChild(button);
        row.appendChild(buttonCell);

        // 将行添加到表格中
        tokenTableBody.appendChild(row);
    });
}

// 显示Top 5专家
function displayTop5Experts(top5Experts) {
    const expertTableBody = document.querySelector('.expert-explanation .token-table tbody');
    if (!expertTableBody) {
        console.error('未找到一级专家组合的tbody元素');
        return;
    }

    // 清空现有的内容
    expertTableBody.innerHTML = '';

    // 遍历Top 5专家，生成每一行的内容
    top5Experts.forEach(expert => {
        const row = document.createElement('tr');

        // 创建Expert Index单元格
        const indexCell = document.createElement('td');
        indexCell.textContent = expert['Expert Index'];
        row.appendChild(indexCell);

        // 创建Expert Name和Function Description单元格
        const infoCell = document.createElement('td');
        const nameDiv = document.createElement('div');
        nameDiv.textContent = expert['Expert Name'];
        const descDiv = document.createElement('div');
        descDiv.textContent = expert['Function Description'];
        descDiv.style.fontSize = '12px'; // 设置功能描述字体大小
        descDiv.style.color = '#666'; // 设置功能描述颜色
        infoCell.appendChild(nameDiv);
        infoCell.appendChild(descDiv);
        row.appendChild(infoCell);

        // 创建"分解"按钮单元格
        const buttonCell = document.createElement('td');
        const button = document.createElement('button');
        button.textContent = '+'; // 按钮文本
        button.classList.add('add-button'); // 添加按钮样式类
        button.addEventListener('click', async () => {
            console.log('分解按钮被点击，专家:', expert['Expert Name']); // 调试信息

            // 生成64维随机向量
            const randomVector = Array.from({ length: 64 }, () => Math.random());
            console.log('生成的64维随机向量:', randomVector); // 调试信息

            try {
                // 发送请求查询Top 5二级专家组合
                const response = await axios.post('http://localhost:3000/api/top5-second-level-experts', {
                    tokenVector: randomVector
                });
                console.log('Top 5二级专家组合:', response.data); // 调试信息

                // 显示Top 5二级专家组合
                displaySecondLevelExperts(response.data);

                // 不点亮圆圈，保持当前状态
                // 一级专家组合的分解不改变MOE网络的显示

                // 高亮当前行和按钮
                const row = button.closest('tr');
                highlightRowAndButton(row, button, 'expert');
            } catch (error) {
                console.error('查询Top 5二级专家组合失败:', error);
            }
        });
        buttonCell.appendChild(button);
        row.appendChild(buttonCell);

        // 将行添加到表格中
        expertTableBody.appendChild(row);
    });
}

// 根据激活向量点亮圆圈
function activateCirclesByVector(vector) {
    const moeNetwork = document.getElementById('moe-network');
    const circles = moeNetwork.querySelectorAll('.circle');
    
    // 清除所有激活状态
    circles.forEach(circle => {
        circle.classList.remove('active');
        circle.style.opacity = '';
    });
    
    if (!vector || !Array.isArray(vector)) {
        console.warn('激活向量无效:', vector);
        return;
    }
    
    console.log(`向量长度: ${vector.length}`);
    
    // 根据向量值点亮圆圈
    // 1728维向量映射到27层x64专家的网格
    // 向量索引对应网格位置：vector[i] 对应第 i%27 列，第 Math.floor(i/27) 行
    let activatedCount = 0;
    circles.forEach((circle, index) => {
        // 网格中的位置：index = row * 27 + col
        const row = Math.floor(index / 27);  // 行（0-63）
        const col = index % 27;              // 列（0-26）
        
        // 向量索引：vectorIndex = col * 64 + row
        const vectorIndex = col * 64 + row;
        
        if (vectorIndex < vector.length && vector[vectorIndex] > 0) {
            circle.classList.add('active');
            activatedCount++;
            
            // 根据激活强度设置透明度
            const maxValue = Math.max(...vector);
            const intensity = Math.min(vector[vectorIndex] / maxValue, 1.0);
            circle.style.opacity = 0.4 + (intensity * 0.6); // 0.4-1.0的透明度
        }
    });
    
    console.log(`点亮了 ${activatedCount} 个圆圈`);
    
    // 统计每列（层）的激活数量
    const layersCount = [];
    for (let col = 0; col < 27; col++) {
        let layerCount = 0;
        for (let row = 0; row < 64; row++) {
            const vectorIndex = col * 64 + row;
            if (vectorIndex < vector.length && vector[vectorIndex] > 0) {
                layerCount++;
            }
        }
        layersCount.push(layerCount);
    }
    console.log('每列激活的专家数量:', layersCount);
}

// 显示二级专家组合
function displaySecondLevelExperts(secondLevelExperts) {
    const secondLevelTableBody = document.querySelector('.expert-decomposition .token-table tbody');
    if (!secondLevelTableBody) {
        console.error('未找到二级专家组合的tbody元素');
        return;
    }

    // 清空现有的内容
    secondLevelTableBody.innerHTML = '';

    // 遍历二级专家组合，生成每一行的内容
    secondLevelExperts.forEach(expert => {
        const row = document.createElement('tr');

        // 创建Expert Index单元格
        const indexCell = document.createElement('td');
        indexCell.textContent = expert['Expert Index'];
        row.appendChild(indexCell);

        // 创建Expert Name和Function Description单元格
        const infoCell = document.createElement('td');
        const nameDiv = document.createElement('div');
        nameDiv.textContent = expert['Expert Name'];
        const descDiv = document.createElement('div');
        descDiv.textContent = expert['Function Description'];
        descDiv.style.fontSize = '12px'; // 设置功能描述字体大小
        descDiv.style.color = '#666'; // 设置功能描述颜色
        infoCell.appendChild(nameDiv);
        infoCell.appendChild(descDiv);
        row.appendChild(infoCell);

        // 将行添加到表格中
        secondLevelTableBody.appendChild(row);
    });
}

// 更新token列表
function updateTokenList(tokenVectors) {
    const tokenTableBody = document.querySelector('.token-list .token-table tbody');
    tokenTableBody.innerHTML = tokenVectors
        .map(({ token }) => `
            <tr>
                <td>${token}</td>
                <td><button class="add-button">+</button></td>
            </tr>
        `)
        .join('');
}

let lastHighlightedRow = null;
let lastHighlightedButton = null;
let lastHighlightedColumn = null;

// 高亮行和按钮
function highlightRowAndButton(row, button, column) {
    // 如果之前有高亮的行和按钮，且点击的是同一列，去除背景和按钮颜色
    if (lastHighlightedRow && lastHighlightedColumn === column) {
        lastHighlightedRow.style.backgroundColor = '';
        lastHighlightedButton.style.backgroundColor = '';
    }

    // 如果之前有高亮的按钮，且点击的是不同列，复原按钮
    if (lastHighlightedButton && lastHighlightedColumn !== column) {
        lastHighlightedButton.style.backgroundColor = '';
    }

    // 高亮当前行和按钮
    row.style.backgroundColor = '#ADD8E6'; // 浅蓝色
    button.style.backgroundColor = '#ADD8E6'; // 浅蓝色

    // 更新最后高亮的行、按钮和列
    lastHighlightedRow = row;
    lastHighlightedButton = button;
    lastHighlightedColumn = column;
} 